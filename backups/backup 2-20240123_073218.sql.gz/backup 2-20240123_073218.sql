CREATE DATABASE IF NOT EXISTS `s126067_student`;

USE `s126067_student`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `role` varchar(55) DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `verified` tinyint(1) DEFAULT NULL,
  `image_url` varchar(255) NOT NULL DEFAULT 'bot.png',
  `notifications` text DEFAULT NULL,
  `email_notifications` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `accounts` VALUES (34,"Administrator","7ece99e593ff5dd200e2b9233d9ba654","aurorahill@gmail.com","2024-01-23 13:18:46","2024-01-23 13:29:25","superadmin","[]",1,"bot.png","[]","[]"),
(35,"Administrator","0192023a7bbd73250516f069df18b500","admin1@gmail.com","2024-01-23 13:21:11","2024-01-23 14:31:06","superadmin","[]","0","35_1gugz4.jpg","[]","[]"),
(36,"ANGELA","21232f297a57a5a743894a0e4a801fc3","angela@gmal.com","2024-01-23 14:28:18","2024-01-23 14:28:18","others","[\"Manage_Accounts\",\"Manage_Residents\",\"View_Reports\"]",1,"bot.png","[]","[]");


DROP TABLE IF EXISTS `officers`;

CREATE TABLE `officers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `officers` VALUES (1,"Levy Lloyd B. Orcales","Punong Barangay","09190052740"),
(2,"Joyce C. Aromin","Kagawad","09465163362"),
(3,"Joseph P. Perez Jr.","Kagawad","09929140716"),
(4,"Oscar F. Oborza","Kagawad","09122061831"),
(5,"Ma. Villagracia B. Manuel","Kagawad","09702070743"),
(6,"Jimmy M. Estepa","Kagawad","09098927011"),
(7,"Junior C. Cosme","Kagawad","09212066881"),
(8,"Jannet C. Sapinoso","Kagawad","09480769823"),
(9,"Kurt Sochin B. Kapawen","SK Chairman","09174196993"),
(10,"Divina K. Oborza","Barangay Secretary","09488432850"),
(11,"Elenita D. Pasagoy","Barangay Treasurer","09393022043"),
(12,"Leander K. Wong","Chief Tanod","09102373502"),
(13,"Marites B. Kapawen","BNS","09185745721"),
(14,"Joanalyn G. Ofianza","Street Sweeper","09317043556");


DROP TABLE IF EXISTS `survey`;

CREATE TABLE `survey` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `LastName` varchar(255) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `MiddleInitial` varchar(10) DEFAULT NULL,
  `BirthPLace` varchar(255) DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `CivilStatus` varchar(20) DEFAULT NULL,
  `Religion` varchar(100) DEFAULT NULL,
  `Dialect` varchar(100) DEFAULT NULL,
  `Education` varchar(255) DEFAULT NULL,
  `Job` varchar(255) DEFAULT NULL,
  `MonthLyIncome` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(255) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Remarks` text DEFAULT NULL,
  `year_added` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_survey_id` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13448 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `survey` VALUES (13446,"awdawda","awdawdawd","awdawd","awdawda","2024-02-24","0","Other","Widowed","adawd","awdawd","awdawd","awdawd","awdawd","awd","awdawd@awda.com","awdawdawd",2024),
(13447,"Lukkanit6","lorean","M","Baguio","2006-02-01",17,"Male","Single","catholic","taglog","college grad","teacher","na","089898786869","masadawd@gmail.com","pwd - ORTHO",2024);


DROP TABLE IF EXISTS `useractivitylogs`;

CREATE TABLE `useractivitylogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `activity` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `UserActivityLogs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `useractivitylogs` VALUES (121,35,"User Administrator has loged in logged in","2024-01-23 13:21:21"),
(122,35,"User Administrator has logged out","2024-01-23 13:29:08"),
(123,35,"User Administrator has loged in logged in","2024-01-23 13:29:13"),
(124,35,"Verified Account with ID: 34","2024-01-23 13:29:25"),
(125,35,"User Administrator has loged in logged in","2024-01-23 14:22:47"),
(126,35,"Updated profile image","2024-01-23 14:31:06");


SET foreign_key_checks = 1;
